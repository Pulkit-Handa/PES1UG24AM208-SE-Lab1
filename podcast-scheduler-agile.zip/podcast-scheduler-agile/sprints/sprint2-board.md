# Sprint 2 — Board Snapshot

**Sprint Goal:** Full outline builder with export, collaborative sharing, and guest invite flow are working end-to-end.  
**Duration:** 1 week  
**Original Capacity:** 26 story points | **Final (after scope change):** 34 pts

---

## ⚠️ Scope Change — Day 2

Story 3.2 (Automated Guest Invites, 8 pts) was pulled in from the backlog mid-sprint at the Product Owner's request. This caused the burndown to **plateau on Day 2** (visible as a flat line) before resuming its descent. Total sprint capacity revised to 34 pts.

---

## Board State: End of Sprint 2

### ✅ Done

| Story | Points | Assignee | Notes |
|---|---|---|---|
| 2.2 — Drag-and-Drop Segment Builder | 8 | Member 3 | `dnd-kit` library, reorder persisted via PATCH API |
| 2.3 — Outline Templates | 3 | Member 4 | 3 templates: Interview, Solo, Panel |
| 4.1 — Export Outline (PDF/MD) | 5 | Member 1 | PDF via `pdfmake`, MD via raw string |
| 4.2 — Share Read-Only Link | 3 | Member 2 | UUID-based link, no auth required to view |
| 1.3 — Recording Reminders | 3 | Member 1 | SendGrid integration, 24h + 1h reminder |
| 5.2 — Notification Preferences | 2 | Member 2 | Toggle per channel (email/SMS/in-app) |
| 2.4 — Timestamps & Speaker Notes | 2 | Member 4 | Per-segment fields, inline edit |
| 3.2 — Automated Guest Invites | 8 | Member 3 | .ics attachment, confirm/decline webhook |

**Total Completed: 34 / 34 pts ✅**

---

## Story Comments (Simulated)

**Story 2.2:**  
> "Used `dnd-kit` over `react-beautiful-dnd` due to maintenance status. Undo via CTRL+Z works for 3 steps." — Member 3

**Story 3.2:**  
> "Guest invite sends .ics calendar file. Webhook at `/api/guest/confirm` updates session status. Tested with Gmail and Outlook." — Member 3

**Story 4.1:**  
> "PDF uses `pdfmake` — no puppeteer dependency. Markdown export is plain text with `##` for segment headers." — Member 1

---

## Sprint Review Notes

- Scope creep on Day 2 (Story 3.2 added) surfaced clearly on the burndown chart
- Team recovered by parallelising 2.2 and 3.2 (Members 3 and 4 worked simultaneously)
- Story 3.2 should have been planned in Sprint 1 given its dependency on the session model
- Velocity for Sprint 2: **34 pts** (inflated by scope addition)

---

## Backlog Remaining After Sprint 2

| Story | Points | Status |
|---|---|---|
| 6.1 — Analytics Dashboard | 8 | Deferred to Sprint 3 |
| **Total Remaining** | **8 pts** | |
