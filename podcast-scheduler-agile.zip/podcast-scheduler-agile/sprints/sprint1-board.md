# Sprint 1 — Board Snapshot

**Sprint Goal:** A logged-in user can schedule recurring sessions, view them on a calendar, and create a basic episode outline with guest info.  
**Duration:** 1 week  
**Capacity:** 31 story points

---

## Board State: End of Sprint 1

### ✅ Done

| Story | Points | Assignee | Notes |
|---|---|---|---|
| 5.1 — Registration & Login | 5 | Member 1 | Google OAuth + email/pass, JWT session |
| 1.1 — Schedule Recording Session | 5 | Member 2 | Date picker, duration field, saved to DB |
| 1.4 — Monthly Calendar View | 5 | Member 1 | FullCalendar.js integration, colour-coded |
| 1.2 — Recurring Schedules | 8 | Member 3 | iCal RRULE, weekly + biweekly supported |
| 2.1 — Create Episode Outline | 5 | Member 4 | Title + description + 3 default segments |
| 3.1 — Add Guest Profile | 3 | Member 2 | Name, bio, social links form |

**Total Completed: 31 / 31 pts ✅**

---

## Story Comments (Simulated)

**Story 5.1:**  
> "Google OAuth redirect working. Tested on Chrome and Safari. JWT refresh token also implemented." — Member 1

**Story 1.2:**  
> "RRULE engine uses the `rrule.js` library. DST handling tested for IST ↔ UTC. Biweekly confirmed." — Member 3

**Story 2.1:**  
> "Default segments: Intro, Main Content, Outro. Can be renamed inline." — Member 4

---

## Sprint Review Notes

- All 31 points completed — on track to ideal burndown line throughout
- No blockers surfaced during daily standups
- Story 1.2 was the most complex — required a mid-sprint design discussion on how recurring edits propagate (edit this one / edit all future / edit all)
- Velocity for Sprint 1: **31 pts**
