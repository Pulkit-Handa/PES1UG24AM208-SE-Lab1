# 🎙️ Podcast Scheduler & Outline Builder — Agile SCRUM Project

> **Lab 2 — Agile Backlog Creation & Sprint Simulation**  
> Course: Software Engineering | PES University  
> Topic: Podcast Scheduler & Outline Building  
> Methodology: Agile SCRUM | Tool: Jira

---

## 📌 Project Overview

A web-based platform that allows podcast creators to **schedule recording sessions**, **build structured episode outlines**, manage guests, and track publishing timelines — all within an intuitive self-service interface.

---

## 🎯 Learning Outcomes Demonstrated

| Outcome | Evidence |
|---|---|
| Define and create Epics & User Stories | 6 Epics, 15 User Stories in Jira |
| Prioritize backlog by business value | MoSCoW + Fibonacci story points |
| Assign Story Points (Fibonacci) | Points assigned per story (see below) |
| Apply Planning Poker | Team estimation session documented |
| Simulate a Sprint | Sprint 1 & Sprint 2 run and completed |
| Monitor via Burndown Chart | Charts exported from Jira (see `/reports/`) |
| Reflect on Agile workflow | See Group Reflection section |

---

## 🗂️ Epics & User Stories

### Epic 1: Podcast Scheduling Engine
**Description:** Enable podcast creators to schedule, manage, and track recording sessions through an intuitive calendar interface.

| Story ID | As a… | I want to… | So that… | Priority | Points |
|---|---|---|---|---|---|
| 1.1 | Podcast host | Schedule a new recording session with date, time, and duration | I can plan my content calendar in advance | Must Have | 5 |
| 1.2 | Podcast host | Set recurring weekly/biweekly recording schedules | I don't have to manually re-schedule every episode | Must Have | 8 |
| 1.3 | Podcast host | Receive email/SMS reminders before recording sessions | I never miss a scheduled recording | Should Have | 3 |
| 1.4 | Podcast host | View all upcoming sessions on a monthly calendar view | I can see my schedule at a glance | Must Have | 5 |

---

### Epic 2: Episode Outline Builder
**Description:** Provide a structured, collaborative tool for building detailed episode outlines with sections and talking points.

| Story ID | As a… | I want to… | So that… | Priority | Points |
|---|---|---|---|---|---|
| 2.1 | Podcast host | Create a new episode outline with title, description, and segment blocks | I have a structured plan before recording | Must Have | 5 |
| 2.2 | Podcast host | Add, reorder, and delete segments (intro, interview, Q&A, outro) via drag-and-drop | I can flexibly restructure my outline during planning | Must Have | 8 |
| 2.3 | Podcast host | Use pre-built outline templates (interview, solo, panel) | I can get started quickly without building from scratch | Should Have | 3 |
| 2.4 | Podcast host | Add timestamps and speaker notes to each segment | I can follow the outline precisely during recording | Could Have | 2 |

---

### Epic 3: Guest Management
**Description:** Enable podcast hosts to manage guest profiles, invitations, and communication within the platform.

| Story ID | As a… | I want to… | So that… | Priority | Points |
|---|---|---|---|---|---|
| 3.1 | Podcast host | Add a guest profile with name, bio, social links, and topic area | I have all guest information in one place | Must Have | 3 |
| 3.2 | Podcast host | Send automated guest invites linked to a scheduled session | Guests can confirm availability directly from the invite | Should Have | 8 |

---

### Epic 4: Export & Publishing
**Description:** Allow hosts to export outlines and share episode plans across tools and collaborators.

| Story ID | As a… | I want to… | So that… | Priority | Points |
|---|---|---|---|---|---|
| 4.1 | Podcast host | Export episode outlines as PDF or Markdown | I can share or print them for recording day | Must Have | 5 |
| 4.2 | Podcast host | Share a read-only outline link with co-hosts or editors | Collaborators can view the plan without editing access | Should Have | 3 |

---

### Epic 5: User Account & Preferences
**Description:** Support user registration, authentication, and personalization settings.

| Story ID | As a… | I want to… | So that… | Priority | Points |
|---|---|---|---|---|---|
| 5.1 | New user | Register and log in with email or Google OAuth | I can securely access my schedules and outlines | Must Have | 5 |
| 5.2 | Registered user | Set notification preferences (email, SMS, in-app) | I only receive alerts through channels I prefer | Should Have | 2 |

---

### Epic 6: Analytics & Reporting
**Description:** Provide hosts with insights into scheduling consistency and outline completion rates.

| Story ID | As a… | I want to… | So that… | Priority | Points |
|---|---|---|---|---|---|
| 6.1 | Podcast host | View a dashboard showing episodes scheduled vs. completed per month | I can track my consistency as a creator | Could Have | 8 |

---

## 📊 Full Backlog Summary

| Story ID | Title | Priority | Story Points |
|---|---|---|---|
| 1.1 | Schedule recording session | Must Have | 5 |
| 1.2 | Recurring schedules | Must Have | 8 |
| 5.1 | User registration & login | Must Have | 5 |
| 2.1 | Create episode outline | Must Have | 5 |
| 2.2 | Drag-and-drop segment builder | Must Have | 8 |
| 4.1 | Export outline to PDF/Markdown | Must Have | 5 |
| 3.1 | Add guest profile | Must Have | 3 |
| 1.4 | Monthly calendar view | Must Have | 5 |
| 1.3 | Recording reminders | Should Have | 3 |
| 3.2 | Automated guest invites | Should Have | 8 |
| 2.3 | Outline templates | Should Have | 3 |
| 4.2 | Share read-only outline link | Should Have | 3 |
| 5.2 | Notification preferences | Should Have | 2 |
| 2.4 | Timestamps & speaker notes | Could Have | 2 |
| 6.1 | Analytics dashboard | Could Have | 8 |
| **Total** | | | **73 pts** |

---

## 🃏 Planning Poker — Story Points Rationale

Story points follow the **Fibonacci sequence** (1, 2, 3, 5, 8, 13…) to reflect increasing uncertainty in larger tasks.

| Story | Rationale |
|---|---|
| 1.2 — Recurring schedules (8 pts) | Complex recurrence logic (weekly/biweekly/custom), edge cases around timezone handling |
| 2.2 — Drag-and-drop builder (8 pts) | Frontend state management, reorder persistence, undo/redo support |
| 3.2 — Guest invites (8 pts) | Email service integration, calendar link generation, confirmation webhook |
| 6.1 — Analytics dashboard (8 pts) | Data aggregation pipeline, charting library, edge cases for sparse data |
| 4.1 — PDF/Markdown export (5 pts) | Template rendering, formatting fidelity, file download flow |
| 1.1, 1.4, 2.1, 5.1 (5 pts each) | Standard CRUD with moderate UI complexity |
| 1.3, 2.3, 3.1, 4.2 (3 pts each) | Well-understood features with minimal integration surface |
| 2.4, 5.2 (2 pts each) | Simple form fields or preference toggles |

---

## 🏃 Sprint Plan

### Sprint 1 — Core Scheduling & Auth
**Duration:** 1 week | **Velocity Target:** 31 story points

| Story | Points |
|---|---|
| 5.1 — User registration & login | 5 |
| 1.1 — Schedule recording session | 5 |
| 1.4 — Monthly calendar view | 5 |
| 1.2 — Recurring schedules | 8 |
| 2.1 — Create episode outline | 5 |
| 3.1 — Add guest profile | 3 |
| **Sprint 1 Total** | **31 pts** |

**Sprint 1 Goal:** A logged-in user can schedule recurring sessions, view them on a calendar, and create a basic episode outline with guest info.

---

### Sprint 2 — Outline Builder, Export & Notifications
**Duration:** 1 week | **Velocity Target:** 29 story points

| Story | Points |
|---|---|
| 2.2 — Drag-and-drop segment builder | 8 |
| 2.3 — Outline templates | 3 |
| 4.1 — Export outline to PDF/Markdown | 5 |
| 4.2 — Share read-only outline link | 3 |
| 1.3 — Recording reminders | 3 |
| 5.2 — Notification preferences | 2 |
| 2.4 — Timestamps & speaker notes | 2 |
| 3.2 — Automated guest invites | 8 |*
| **Sprint 2 Total** | **34 pts** |

> *Story 3.2 was moved from the backlog into Sprint 2 mid-sprint (scope creep — flagged on burndown).

**Sprint 2 Goal:** Full outline builder with export, collaborative sharing, and guest invite flow are working end-to-end.

---

## 📉 Burndown Charts

See [`/reports/`](./reports/) for exported Jira burndown data.

### Sprint 1 Burndown Summary

| Day | Remaining Points |
|---|---|
| Day 1 (Start) | 31 |
| Day 2 | 26 |
| Day 3 | 18 |
| Day 4 | 11 |
| Day 5 | 5 |
| Day 7 (End) | 0 |

✅ Sprint 1 completed on time — team tracked closely to the ideal line.

### Sprint 2 Burndown Summary

| Day | Remaining Points |
|---|---|
| Day 1 (Start) | 26 |
| Day 2 | 26 *(Story 3.2 added — scope creep)* |
| Day 3 | 22 |
| Day 4 | 16 |
| Day 5 | 9 |
| Day 6 | 3 |
| Day 7 (End) | 0 |

⚠️ Sprint 2 showed a **flat day on Day 2** due to mid-sprint addition of Story 3.2 (Guest Invites, 8 pts). The sharp drop on Days 4–5 suggests the team recovered by parallelising tasks. This is a textbook scope creep signal on a burndown chart.

---

## 💬 Group Reflection

**What went well:**
- Sprint 1 was well-estimated — all stories completed within velocity.
- Planning Poker surfaced a disagreement on Story 3.2 (some estimated 5, others 13), leading to a productive breakdown of the invite confirmation webhook complexity.
- Drag-and-drop builder (Story 2.2) was correctly flagged as 8 points — the undo/redo state was indeed complex.

**What could improve:**
- Story 3.2 should have been in Sprint 1 backlog from the start; mid-sprint addition introduced schedule pressure.
- Timestamps & speaker notes (Story 2.4) could have been broken into two separate stories (timestamps = 1 pt, speaker notes = 1 pt) for finer tracking.
- Analytics dashboard (Story 6.1, 8 pts) was intentionally deferred to a future sprint — good prioritization call given the complexity.

**Key Agile Insight:**  
The burndown chart's flat line on Sprint 2 Day 2 is exactly the kind of scope creep indicator the chart is designed to surface. In a real project, this would trigger a conversation with the Product Owner about whether the new story should replace an existing one or extend the sprint.

---

## 📁 Repository Structure

```
podcast-scheduler-agile/
├── README.md                    # This file — full lab documentation
├── docs/
│   ├── epics-and-stories.md     # Detailed Epic/Story breakdown
│   ├── planning-poker-notes.md  # Estimation session notes
│   └── sprint-planning.md       # Sprint 1 & 2 planning docs
├── sprints/
│   ├── sprint1-board.md         # Sprint 1 Jira board snapshot
│   └── sprint2-board.md         # Sprint 2 Jira board snapshot
└── reports/
    ├── burndown-sprint1.md      # Sprint 1 burndown data
    └── burndown-sprint2.md      # Sprint 2 burndown data
```

---

## 🛠️ Tools Used

- **Jira** — Backlog, Sprint, and Burndown management
- **Agile SCRUM** — Methodology
- **Planning Poker** — Collaborative estimation
- **GitHub** — Version control and deliverable submission

---

*Lab 2 — PES University | B.Tech CSE (AI/ML) | SRN: PES1UG24AM208*
