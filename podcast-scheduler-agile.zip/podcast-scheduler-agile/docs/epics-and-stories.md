# Epics & User Stories — Podcast Scheduler & Outline Builder

## Epic 1: Podcast Scheduling Engine

**Description:** Enable podcast creators to schedule, manage, and track recording sessions through an intuitive calendar interface.

### Story 1.1 — Schedule Recording Session
- **As a** podcast host
- **I want to** schedule a new recording session with date, time, and duration
- **So that** I can plan my content calendar in advance
- **Priority:** Must Have | **Story Points:** 5
- **Acceptance Criteria:**
  - Host can pick a date from a date picker
  - Host can set start time and duration
  - Session appears on the calendar immediately after saving
  - Session can be edited or cancelled

### Story 1.2 — Recurring Schedules
- **As a** podcast host
- **I want to** set recurring weekly/biweekly recording schedules
- **So that** I don't have to manually re-schedule every episode
- **Priority:** Must Have | **Story Points:** 8
- **Acceptance Criteria:**
  - Supports weekly, biweekly, and monthly recurrence
  - Host can set an end date or number of occurrences
  - Individual recurrences can be edited without affecting the series

### Story 1.3 — Recording Reminders
- **As a** podcast host
- **I want to** receive email/SMS reminders before recording sessions
- **So that** I never miss a scheduled recording
- **Priority:** Should Have | **Story Points:** 3
- **Acceptance Criteria:**
  - Reminder sent 24 hours and 1 hour before session
  - Channel (email/SMS) configurable per user

### Story 1.4 — Monthly Calendar View
- **As a** podcast host
- **I want to** view all upcoming sessions on a monthly calendar view
- **So that** I can see my schedule at a glance
- **Priority:** Must Have | **Story Points:** 5
- **Acceptance Criteria:**
  - Calendar shows all sessions colour-coded by status (Scheduled / Recorded / Cancelled)
  - Clicking a session opens its detail panel

---

## Epic 2: Episode Outline Builder

**Description:** Provide a structured, collaborative tool for building detailed episode outlines with sections and talking points.

### Story 2.1 — Create Episode Outline
- **As a** podcast host
- **I want to** create a new episode outline with title, description, and segment blocks
- **So that** I have a structured plan before recording
- **Priority:** Must Have | **Story Points:** 5

### Story 2.2 — Drag-and-Drop Segment Builder
- **As a** podcast host
- **I want to** add, reorder, and delete segments (intro, interview, Q&A, outro) via drag-and-drop
- **So that** I can flexibly restructure my outline during planning
- **Priority:** Must Have | **Story Points:** 8

### Story 2.3 — Outline Templates
- **As a** podcast host
- **I want to** use pre-built outline templates (interview, solo, panel)
- **So that** I can get started quickly without building from scratch
- **Priority:** Should Have | **Story Points:** 3

### Story 2.4 — Timestamps & Speaker Notes
- **As a** podcast host
- **I want to** add timestamps and speaker notes to each segment
- **So that** I can follow the outline precisely during recording
- **Priority:** Could Have | **Story Points:** 2

---

## Epic 3: Guest Management

**Description:** Enable podcast hosts to manage guest profiles, invitations, and communication within the platform.

### Story 3.1 — Guest Profile
- **As a** podcast host
- **I want to** add a guest profile with name, bio, social links, and topic area
- **So that** I have all guest information in one place
- **Priority:** Must Have | **Story Points:** 3

### Story 3.2 — Automated Guest Invites
- **As a** podcast host
- **I want to** send automated guest invites linked to a scheduled session
- **So that** guests can confirm availability directly from the invite
- **Priority:** Should Have | **Story Points:** 8

---

## Epic 4: Export & Publishing

**Description:** Allow hosts to export outlines and share episode plans across tools and collaborators.

### Story 4.1 — Export Outline (PDF/Markdown)
- **As a** podcast host
- **I want to** export episode outlines as PDF or Markdown
- **So that** I can share or print them for recording day
- **Priority:** Must Have | **Story Points:** 5

### Story 4.2 — Share Read-Only Link
- **As a** podcast host
- **I want to** share a read-only outline link with co-hosts or editors
- **So that** collaborators can view the plan without editing access
- **Priority:** Should Have | **Story Points:** 3

---

## Epic 5: User Account & Preferences

**Description:** Support user registration, authentication, and personalization settings.

### Story 5.1 — Registration & Login
- **As a** new user
- **I want to** register and log in with email or Google OAuth
- **So that** I can securely access my schedules and outlines
- **Priority:** Must Have | **Story Points:** 5

### Story 5.2 — Notification Preferences
- **As a** registered user
- **I want to** set notification preferences (email, SMS, in-app)
- **So that** I only receive alerts through channels I prefer
- **Priority:** Should Have | **Story Points:** 2

---

## Epic 6: Analytics & Reporting

**Description:** Provide hosts with insights into scheduling consistency and outline completion rates.

### Story 6.1 — Creator Dashboard
- **As a** podcast host
- **I want to** view a dashboard showing episodes scheduled vs. completed per month
- **So that** I can track my consistency as a creator
- **Priority:** Could Have | **Story Points:** 8
