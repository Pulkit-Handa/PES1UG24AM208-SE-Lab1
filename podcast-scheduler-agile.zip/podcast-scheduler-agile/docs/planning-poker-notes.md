# Planning Poker Session Notes

## What is Planning Poker?

Planning Poker is a consensus-based estimation technique used in Agile. Each team member holds a card from the Fibonacci deck (0, 1, 2, 3, 5, 8, 13, 20, 40, 100). Everyone simultaneously reveals their estimate; if estimates differ, the highest and lowest estimators explain their reasoning, and the team re-votes until consensus is reached.

**Why Fibonacci?** Larger tasks carry more uncertainty. The non-linear gaps in the Fibonacci sequence naturally represent this — the difference between 8 and 13 is not the same cognitive distance as between 1 and 2, which mirrors real-world complexity scaling.

---

## Session Summary

**Stories discussed:** All 15 backlog items  
**Team size:** 4 members  
**Format:** Each member wrote their estimate on paper; revealed simultaneously

---

## Notable Disagreements & Resolutions

### Story 1.2 — Recurring Schedules
| Member | Estimate |
|---|---|
| Member 1 | 5 |
| Member 2 | 8 |
| Member 3 | 8 |
| Member 4 | 13 |

**Discussion:** Member 4 flagged timezone edge cases (DST transitions, user TZ vs server TZ), cross-month recurrence boundaries, and the need for a recurrence rule engine (iCal RRULE format). Member 1 had underestimated the persistence complexity. **Consensus: 8 pts.**

---

### Story 3.2 — Automated Guest Invites
| Member | Estimate |
|---|---|
| Member 1 | 5 |
| Member 2 | 5 |
| Member 3 | 8 |
| Member 4 | 13 |

**Discussion:** Initially split between 5 and 13. Members 3 and 4 raised: email service integration (SendGrid/SES), calendar invite generation (.ics), confirmation webhook, and handling non-responses. After discussion, 13 was brought down as the webhook logic is simpler than assumed. **Consensus: 8 pts.**

---

### Story 2.2 — Drag-and-Drop Segment Builder
| Member | Estimate |
|---|---|
| Member 1 | 8 |
| Member 2 | 8 |
| Member 3 | 5 |
| Member 4 | 8 |

**Discussion:** Member 3 assumed a third-party DnD library would handle most of it. Members 1, 2, 4 pointed out reorder persistence to backend, undo/redo stack, and mobile touch events add significant effort. **Consensus: 8 pts.**

---

### Story 6.1 — Analytics Dashboard
| Member | Estimate |
|---|---|
| Member 1 | 8 |
| Member 2 | 8 |
| Member 3 | 13 |
| Member 4 | 8 |

**Discussion:** Member 3 was concerned about sparse data edge cases and historical rollup queries. Team agreed the MVP dashboard (scheduled vs completed counts, bar chart) is 8 pts; advanced cohort analysis would push to 13. **Consensus: 8 pts.**

---

## Final Estimates (All Stories)

| Story | Final Points |
|---|---|
| 1.1 Schedule recording session | 5 |
| 1.2 Recurring schedules | 8 |
| 1.3 Recording reminders | 3 |
| 1.4 Monthly calendar view | 5 |
| 2.1 Create episode outline | 5 |
| 2.2 Drag-and-drop segment builder | 8 |
| 2.3 Outline templates | 3 |
| 2.4 Timestamps & speaker notes | 2 |
| 3.1 Guest profile | 3 |
| 3.2 Automated guest invites | 8 |
| 4.1 Export outline (PDF/MD) | 5 |
| 4.2 Share read-only link | 3 |
| 5.1 Registration & login | 5 |
| 5.2 Notification preferences | 2 |
| 6.1 Analytics dashboard | 8 |
| **Total** | **73** |
