# Sprint Planning Document

## Backlog Prioritization (MoSCoW)

Stories were ranked using MoSCoW prioritization before sprint assignment.

| Priority | Stories |
|---|---|
| Must Have | 1.1, 1.2, 1.4, 2.1, 2.2, 3.1, 4.1, 5.1 |
| Should Have | 1.3, 2.3, 3.2, 4.2, 5.2 |
| Could Have | 2.4, 6.1 |
| Won't Have (this release) | — |

---

## Backlog Ordering (Ranked by Business Value + Dependencies)

1. **5.1** — Registration & Login *(foundation — everything depends on auth)*
2. **1.1** — Schedule Recording Session *(core feature)*
3. **1.4** — Monthly Calendar View *(core feature, depends on 1.1)*
4. **1.2** — Recurring Schedules *(core feature, depends on 1.1)*
5. **2.1** — Create Episode Outline *(core feature)*
6. **3.1** — Add Guest Profile *(core feature)*
7. **2.2** — Drag-and-Drop Segment Builder *(depends on 2.1)*
8. **4.1** — Export Outline (PDF/MD) *(depends on 2.1)*
9. **2.3** — Outline Templates *(depends on 2.1)*
10. **4.2** — Share Read-Only Link *(depends on 4.1)*
11. **1.3** — Recording Reminders *(depends on 5.1 notifications)*
12. **5.2** — Notification Preferences *(depends on 5.1)*
13. **3.2** — Automated Guest Invites *(depends on 3.1 + 1.1)*
14. **2.4** — Timestamps & Speaker Notes *(depends on 2.2)*
15. **6.1** — Analytics Dashboard *(depends on completed sessions data)*

---

## Sprint 1 Selection Rationale

Sprint 1 pulls all **Must Have** foundation stories:
- Auth (5.1) must be first — it's a prerequisite for everything
- Core scheduling stories (1.1, 1.2, 1.4) are the product's primary value proposition
- Outline creation (2.1) and guest profile (3.1) are low-complexity Must Haves that fit the velocity

**Velocity Target: 31 pts** (conservative for first sprint)

---

## Sprint 2 Selection Rationale

Sprint 2 focuses on **depth** — enhancing the outline builder and adding collaboration/export:
- 2.2 and 2.3 extend the outline builder from Sprint 1
- 4.1 and 4.2 add export and sharing — high user value
- 1.3 and 5.2 complete the notification loop
- 2.4 is a small quality-of-life improvement

**Velocity Target: 26 pts** *(Story 3.2 was backlog at sprint start)*

---

## Velocity Trend

| Sprint | Planned | Completed | Planned Velocity |
|---|---|---|---|
| Sprint 1 | 31 | 31 | 31 |
| Sprint 2 | 26 | 34* | 26 |

*34 includes 8 pts of unplanned scope added mid-sprint.

**Projected Sprint 3 velocity: ~28–32 pts**
