# Sprint 1 — Burndown Report

**Sprint Duration:** 7 days  
**Total Story Points Committed:** 31  
**Total Completed:** 31  
**Status:** ✅ Completed on time

---

## Burndown Data

| Day | Ideal Remaining | Actual Remaining | Work Completed |
|---|---|---|---|
| Day 0 (Start) | 31 | 31 | — |
| Day 1 | 26.6 | 26 | Story 5.1 completed (5 pts) |
| Day 2 | 22.1 | 18 | Story 1.1 completed (5 pts) + Story 1.4 in progress |
| Day 3 | 17.7 | 13 | Story 1.4 completed (5 pts) |
| Day 4 | 13.3 | 8 | Story 3.1 completed (3 pts) + Story 2.1 partially done |
| Day 5 | 8.8 | 5 | Story 2.1 completed (5 pts) — Story 1.2 in progress |
| Day 6 | 4.4 | 3 | Story 1.2 in final testing |
| Day 7 (End) | 0 | 0 | Story 1.2 completed (8 pts) |

---

## Chart Description (Jira Burndown)

```
31 |*
28 | \  ← Ideal line (grey)
25 |  \    * ← Actual line (red)
22 |   \  /
19 |    \/
16 |    /\
13 |   /  \
10 |  /    \
 7 | /      \
 4 |/        \
 1 |          *
 0 +---+---+---+---+---+---+---
   D0  D1  D2  D3  D4  D5  D6  D7
```

**Reading:** The actual line (red) tracked closely below the ideal line (grey), indicating the team completed work slightly ahead of schedule on Days 1–4 before the largest story (1.2, 8 pts) landed on Day 7.

---

## Observations

1. Team delivered all 31 committed points
2. Actual line was consistently near or below the ideal line — good estimation
3. Story 1.2 (8 pts, recurring schedules) was the last to complete, as expected for the highest-complexity item
4. No scope changes during Sprint 1
