# Sprint 2 — Burndown Report

**Sprint Duration:** 7 days  
**Original Committed:** 26 pts | **Final (post scope change):** 34 pts  
**Total Completed:** 34  
**Status:** ✅ Completed on time

---

## Burndown Data

| Day | Ideal Remaining | Actual Remaining | Event |
|---|---|---|---|
| Day 0 (Start) | 26 | 26 | Sprint begins |
| Day 1 | 22.3 | 21 | Story 2.3 completed (3 pts) |
| Day 2 | 18.6 | 26 | ⚠️ Story 3.2 added mid-sprint (+8 pts) — flat line |
| Day 3 | 14.9 | 18 | Stories 5.2 and 2.4 completed (4 pts) |
| Day 4 | 11.1 | 10 | Story 4.2 and 1.3 completed (6 pts) |
| Day 5 | 7.4 | 5 | Story 4.1 completed (5 pts) |
| Day 6 | 3.7 | 2 | Story 2.2 partially done |
| Day 7 (End) | 0 | 0 | Stories 2.2 and 3.2 completed (10 pts) |

---

## Chart Description

```
34 |        *  ← Spike: Story 3.2 added Day 2
31 |
28 |*  *
25 |      ↑ FLAT (scope creep signal)
22 |         \
19 |          \
16 |           \
13 |            \
10 |             \
 7 |              \
 4 |               \
 1 |                *
 0 +---+---+---+---+---+---+---
   D0  D1  D2  D3  D4  D5  D6  D7
```

**Key Signal:** The **flat line on Day 2** (actual remaining went from 21 back up to 26) is the burndown chart's way of flagging scope creep. This is a textbook example of what the Jira burndown report surfaces automatically.

---

## Observations

1. **Scope creep detected:** Story 3.2 added mid-sprint on Day 2. Burndown flatlined visually.
2. **Recovery:** Team parallelised Story 2.2 (Member 3) and Story 3.2 (Member 4) on Days 3–7 to absorb the extra 8 pts.
3. **Implication:** Mid-sprint story additions violate the sprint commitment principle in Scrum. In a real project, the PO and Scrum Master would decide whether to swap it in for an existing story or extend the sprint.
4. **Final velocity:** 34 pts — but 8 pts were unplanned, so effective planned velocity was 26 pts (consistent with Sprint 1).
